//
//  DarkSkyApiDelegate.swift
//  InnerWorld
//
//  Created by Linh Nguyen on 3/10/18.
//  Copyright © 2018 Linh Nguyen. All rights reserved.
//

import Foundation

protocol DarkSkyApiDelegate: class {
    func apiCallback()
}
