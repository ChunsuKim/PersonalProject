//
//  Diary+CoreDataClass.swift
//  InnerWorld
//
//  Created by Linh Nguyen on 27/9/18.
//  Copyright © 2018 Linh Nguyen. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Diary)
public class Diary: NSManagedObject {

}
