//
//  User+CoreDataClass.swift
//  InnerWorld
//
//  Created by Linh Nguyen on 5/10/18.
//  Copyright © 2018 Linh Nguyen. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {

}
