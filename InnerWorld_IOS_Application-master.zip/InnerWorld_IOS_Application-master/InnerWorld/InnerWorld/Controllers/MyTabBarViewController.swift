//
//  tabBarViewController.swift
//  InnerWorld
//
//  Created by Jacky Tang on 31/8/18.
//  Copyright © 2018 Jacky Tang. All rights reserved.
//

import UIKit

class MyTabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
